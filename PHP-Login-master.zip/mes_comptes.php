<?php
session_start(); // à mettre tout en haut du fichier .php, cette fonction propre à PHP servira à maintenir la $_SESSION

print_r($_SESSION['data']);

echo "</br>";

$id_cc = $_SESSION['data']['id_cc'];

    //on vérifie que la connexion s'effectue correctement:
$mysqli = mysqli_connect("localhost", "root", "root", "compte_client");

    if(!$mysqli){
        echo "Erreur de connexion à la base de données.";
    } else {
		$Requete = mysqli_query($mysqli,"SELECT * FROM compte WHERE id_compte_bc = '".$id_cc."'");
		if(mysqli_num_rows($Requete) == 0) {
            echo "Aucun compte trouvé par rapport à l'utilisateur.";
        } else {
            // on ouvre la session avec $_SESSION:
			$i = 0;
			while($donnees = $Requete->fetch_array(MYSQL_ASSOC))
			{
				// on va afficher les informations comptes 
				echo "<a href=detail_compte.php?compte=".$donnees['id_compte_bc'].">".$donnees['libelle_bc']."</a></br>";
			}
        }
	}


	$url = "https://api.bitfinex.com/v1/ticker/btcusd";
	$json = json_decode(file_get_contents($url), true);
	$price = $json["last_price"];
	echo $price;
	
	echo "</br>";
	
	$url = "https://api.fixer.io/latest";
	$json = json_decode(file_get_contents($url), true);
	$price = $json["rates"]["USD"];
	echo $price;
	


